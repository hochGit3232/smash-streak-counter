﻿smash_streak 用ファイターアイコン

■ 内容
assets/fighters/ : 通常カラーの透過PNG 91枚（ツールの86項目＋個別ポケモン3体＋ホムラ・ヒカリ）
fighter_icons.json : roster.pyと完全一致する日本語名→相対画像パス
fighter_icons.js : 同じ対応表を window.FIGHTER_ICONS として公開
fighter_icons.csv : Excelで開けるUTF-8 BOM付き対応表
manifest.json : 各画像のサイズ、英語別名、取得元URL
preview.html : 全画像の表示確認（ダブルクリックで開けます）

■ 画像仕様
基本200×200。Mii3種・ポケモン3体・ヒカリは64×64のゲーム内画像です。
無理な拡大はしていません。すべてRGBA透過PNGで、UIでは28px程度の表示を推奨。
ポケモントレーナーにはトレーナー、ホムラ/ヒカリには通常選択のホムラの画像を割り当てています。
個別表示したい場合はゼニガメ/フシギソウ/リザードン/ホムラ/ヒカリのキーも使えます。
通常カラーのみ。アレックス等の別衣装キャラはツールの既存の集約に合わせています。

■ 組み込み
このフォルダの中身をsmash_streakフォルダへコピーします。
元ツールは変更していません。現状のHTTPサーバーは静的画像を配信しないため、次も必要です。

1. streak_counter.py の H.do_GET 内で p = self.path.split("?")[0] の直後に追加:

            if p == "/fighter_icons.js":
                return self._send((BASE / "fighter_icons.js").read_text(encoding="utf-8"), "application/javascript")
            if p.startswith("/assets/fighters/"):
                filename = p.removeprefix("/assets/fighters/")
                if "/" in filename or "\\" in filename or not filename.endswith(".png"):
                    self.send_error(404)
                    return
                path = BASE / "assets" / "fighters" / filename
                if not path.is_file():
                    self.send_error(404)
                    return
                data = path.read_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "image/png")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
                return

2. dock.html と overlay.html の既存の <script> の前に追加:

<script src="/fighter_icons.js"></script>

3. キャラ表示の要素は次のように作れます（textContent/DOMを使うため名前のHTMLエスケープ不要）:

function fighterBadge(x) {
  const badge = document.createElement('span');
  badge.style.cssText = 'display:inline-flex;align-items:center;gap:3px;vertical-align:middle';
  const file = window.FIGHTER_ICONS[x.name];
  if (file) {
    const img = document.createElement('img');
    img.src = '/' + file;
    img.alt = x.name;
    img.title = x.name;
    img.width = img.height = 28;
    img.style.objectFit = 'contain';
    img.onerror = () => img.replaceWith(document.createTextNode(x.name));
    badge.append(img);
  } else {
    badge.append(document.createTextNode(x.name));
  }
  badge.append(document.createTextNode('×' + x.count));
  return badge;
}

4. dock.html の苦手表示の2行を次に置き換え:

  const nem = document.getElementById('nem');
  nem.replaceChildren(document.createTextNode('苦手：'));
  if (s.nemesis.length) {
    s.nemesis.forEach((x, i) => {
      if (i) nem.append(document.createTextNode(' / '));
      nem.append(fighterBadge(x));
    });
  } else nem.append(document.createTextNode('まだなし'));

overlay.html も同様に nem.innerHTML の代わりに fighterBadge を append します。
変更後はツールを再起動し、OBSブラウザソースを再読み込みしてください。

■ 出典
SmashWikiの各画像ページと元画像URLはmanifest.jsonに記載。
https://www.ssbwiki.com/Category:Head_icons_(SSBU)
画像の権利は各権利者に帰属します。この素材集独自の再利用許諾を付与するものではありません。
